

async function main() {
    const Box = await ethers.getContractFactory("Coin11");
    console.log("Deploying Test...");
    const box = await upgrades.deployProxy(Box,  { initialize: 'initializer' });
    console.log("Box deployed to:", box.address);
  }
  
  main()
    .then(() => process.exit(0))
    .catch(error => {
      console.error(error);
      process.exit(1);
    });