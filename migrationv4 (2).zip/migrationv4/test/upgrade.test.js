let tx = await bep20proxy.methods.upgradeTo(newInstance.address).send({from: proxyAdmin});
 bep20proxy.getPastEvents("Upgraded", {fromBlock: 0, toBlock: "latest"}).then(console.log)